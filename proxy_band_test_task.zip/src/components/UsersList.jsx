import React from 'react'
import UserCard from './UserCard'

const UsersList = ({users, getUserAlbums, getUserPosts}) => {
  return (
    <div>
        {users.map((u) => (
        <UserCard
        key={u.id}
          u={u}
          getUserAlbums={getUserAlbums}
          getUserPosts={getUserPosts}
        />
      ))}
    </div>
  )
}

export default UsersList