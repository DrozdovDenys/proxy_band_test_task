import React from 'react'

const UserCard = ({u, getUserPosts, getUserAlbums}) => {
  return (
    <article
    style={{ border: "2px solid", margin: "10px", padding: "10px" }}
  >
    <h5>
      {u.id}. {u.name}
    </h5>
    <h6>{u.company.name}</h6>
    <p>{u.company.catchPhrase}</p>
    <span>{u.email}</span> <span>{u.phone}</span>
    <div>
      <button
        onClick={() => {
          getUserPosts(u.id, u.name);
        }}
      >
        posts
      </button>
      <button onClick={() => {
          getUserAlbums(u.id, u.name);
        }}>albums</button>
    </div>
  </article>
  )
}

export default UserCard