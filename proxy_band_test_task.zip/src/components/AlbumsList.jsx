import React from "react";
import AlbumCard from "./AlbumCard";

const AlbumsList = ({ userName, userAlbums }) => {
  return (
    <div>
      <h2>{userName}`s Albums:</h2>
      <ul style={{ padding: 0 }}>
        {userAlbums.map((a) => (
          <AlbumCard a={a} key={a.id}/>
        ))}
      </ul>
    </div>
  );
};

export default AlbumsList;
