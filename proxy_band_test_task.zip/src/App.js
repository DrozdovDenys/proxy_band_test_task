import "./App.css";
import React, { useEffect, useState } from "react";
import axios from "axios";
import UserCard from "./components/UserCard";
import UsersList from "./components/UsersList";
import UsersService from "./API/UsersService";
import { MyModal } from "./components/MyModal/MyModal";
import AlbumCard from "./components/AlbumCard";
import AlbumsList from "./components/AlbumsList";

function App() {
  const [users, setUsers] = useState([]);
  const [userName, setUserName] = useState("");
  const [userPosts, setUserPosts] = useState([]);
  const [userAlbums, setUserAlbums] = useState([]);

  const [modal, setModal] = useState(false);
  const [visible, setVisible] = useState(false);

  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    getUsers();
  }, []);

  const getUsers = async () => {
    setIsLoading(true);
    const users = await UsersService.getUsers();
    setIsLoading(false);
    setUsers(users);
    console.log(users);
  };

  const getUserPosts = async (id, name) => {
    const posts = await UsersService.getUserPosts(id, name);
    setUserPosts(posts);
    setUserName(name);
  };

  const getUserAlbums = async (id, name) => {
    const albums = await UsersService.getUserAlbums(id, name);
    setUserAlbums(albums);
    setModal(true);
    setUserName(name);
  };

  return (
    <div className="App">
      <MyModal visible={modal} setVisible={setModal}>
        <AlbumsList userName={userName} userAlbums={userAlbums} />
      </MyModal>
      <h1>Proxy Brand test task</h1>
      {isLoading ? (
        <h2>Loading....</h2>
      ) : (
        <>
          <h2>Users:</h2>
          <UsersList
            users={users}
            getUserPosts={getUserPosts}
            getUserAlbums={getUserAlbums}
          />
        </>
      )}
    </div>
  );
}

export default App;
